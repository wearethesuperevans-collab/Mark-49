# MARK LIV — Web Version

A browser-ready version of the original MARK LIV project.

**AI:** Gemini through a server-side API key  
**Web search:** original MARK LIV search module  
**Frontend:** browser chat + voice input + speech output  
**Backend:** FastAPI  
**Deployment:** Render or another Python host

See `WEB-DEPLOY.md`.
