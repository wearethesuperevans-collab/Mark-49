# MARK LIV Web deployment

This version keeps the original MARK LIV AI/search core and adds a browser-ready FastAPI web server.

## Run locally
1. Install Python 3.11+.
2. `pip install -r requirements-web.txt`
3. Set `GEMINI_API_KEY` to your Gemini API key.
4. Optional: set `MARK_ACCESS_KEY` to protect the website.
5. Run: `uvicorn web_server:app --host 0.0.0.0 --port 8000`
6. Open `http://localhost:8000`

## Deploy online
The included `render.yaml` is ready for Render. Put the project in a GitHub repository, create a Render Web Service from that repository, and add the secret `GEMINI_API_KEY` in Render's environment settings. Do not put your API key in GitHub.

## Important
The original desktop-only features (controlling the computer, local apps, microphone hardware, etc.) cannot safely execute on a normal cloud web server. The web version exposes the AI and web-search capabilities and does not pretend the browser can control a remote user's computer.
