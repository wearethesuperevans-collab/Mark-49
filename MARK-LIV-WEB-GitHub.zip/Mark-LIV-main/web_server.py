
import os
import secrets
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware

BASE = Path(__file__).resolve().parent
WEB = BASE / "web"

app = FastAPI(title="MARK LIV Web", docs_url=None, redoc_url=None)

# Browser can be hosted separately (e.g. GitHub Pages) and talk to this backend.
allowed = os.getenv("MARK_CORS_ORIGINS", "*")
origins = [x.strip() for x in allowed.split(",") if x.strip()] or ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

ACCESS_KEY = os.getenv("MARK_ACCESS_KEY", "").strip()
_sessions: set[str] = set()

SYSTEM_PROMPT = """
You are MARK LIV, a capable personal AI assistant.
Be direct, helpful, accurate, and conversational.
You are running through a web interface, so do not claim you physically changed
the user's device, opened an app, clicked something, or controlled hardware unless
the web backend actually performed that operation.
You can answer questions, reason, write and debug code, summarize, explain,
research current information when web search is requested, and work with text
provided by the user.
"""

def _authorized(request: Request) -> bool:
    if not ACCESS_KEY:
        return True
    auth = request.headers.get("authorization", "")
    return auth.startswith("Bearer ") and auth[7:].strip() in _sessions

def _token() -> str:
    t = secrets.token_urlsafe(32)
    _sessions.add(t)
    return t

@app.get("/", response_class=HTMLResponse)
async def index():
    return HTMLResponse((WEB / "index.html").read_text(encoding="utf-8"))

@app.get("/health")
async def health():
    return {
        "ok": True,
        "ai_configured": bool(os.getenv("GEMINI_API_KEY", "").strip()),
        "access_key_enabled": bool(ACCESS_KEY),
    }

@app.post("/api/login")
async def login(request: Request):
    if not ACCESS_KEY:
        return {"ok": True, "token": ""}
    body = await request.json()
    if str(body.get("key", "")).strip() != ACCESS_KEY:
        return JSONResponse({"ok": False, "error": "Invalid access key"}, status_code=401)
    return {"ok": True, "token": _token()}

@app.post("/api/chat")
async def chat(request: Request):
    if not _authorized(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)

    body = await request.json()
    message = str(body.get("message", "")).strip()
    history = body.get("history", [])

    if not message:
        return JSONResponse({"error": "Message is required"}, status_code=400)

    try:
        from core.gemini import text

        contents = [{"role": "user", "parts": [{"text": SYSTEM_PROMPT}]}]
        # Keep a modest rolling conversation context.
        for item in history[-12:]:
            role = "model" if item.get("role") == "assistant" else "user"
            txt = str(item.get("content", "")).strip()
            if txt:
                contents.append({"role": role, "parts": [{"text": txt}]})
        contents.append({"role": "user", "parts": [{"text": message}]})

        answer = text(contents, tier="SMART", timeout_ms=30000, default="")
        if not answer:
            return JSONResponse(
                {"error": "MARK could not get an AI response. Check GEMINI_API_KEY and your API quota."},
                status_code=502,
            )
        return {"ok": True, "reply": answer}
    except Exception as exc:
        return JSONResponse({"error": f"MARK backend error: {type(exc).__name__}: {exc}"}, status_code=500)

@app.post("/api/search")
async def search(request: Request):
    if not _authorized(request):
        return JSONResponse({"error": "Unauthorized"}, status_code=401)
    body = await request.json()
    query = str(body.get("query", "")).strip()
    if not query:
        return JSONResponse({"error": "Query is required"}, status_code=400)
    try:
        from actions.web_search import _search
        result = _search(query)
        return {"ok": True, "result": result}
    except Exception as exc:
        return JSONResponse({"error": f"Search error: {type(exc).__name__}: {exc}"}, status_code=500)

@app.get("/static/{name}")
async def static_file(name: str):
    path = WEB / "static" / name
    if not path.is_file():
        return JSONResponse({"error": "Not found"}, status_code=404)
    return FileResponse(path)

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("web_server:app", host="0.0.0.0", port=port)
